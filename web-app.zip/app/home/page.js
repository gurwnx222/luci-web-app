"use client";
import { useState } from "react";

import BookingPage from "../components/Booking";
import ChatPage from "../components/Chats";
import NavbarStudio from "../components/NavbarStudio";
import SubscriptionPage from "../components/Subscription";

export default function Home() {
  const [activeTab, setActiveTab] = useState("booking");


  return (
    <div className="bg-[#262628] min-h-screen w-full">
      <section className="w-full flex flex-col lg:flex-row h-auto min-h-screen">
        <div className="flex flex-col w-full lg:w-1/3 xl:w-1/4">
          <div className="w-full px-4 sm:px-6 lg:px-10 py-8 sm:py-10 lg:py-14">
            <NavbarStudio />
          </div>
          {/* left side option bar */}
          <div className="w-full px-4 sm:px-6 lg:px-10">
            <div className="text-sm font-normal leading-tight text-[#FFF6EF]">
              Main Menu
            </div>

            <div className="mt-4 flex flex-row lg:flex-col gap-2 sm:gap-3 overflow-x-auto lg:overflow-x-visible pb-2 lg:pb-0">
              <button
                className={`cursor-pointer flex p-3 sm:p-4 gap-2 h-11 items-center whitespace-nowrap flex-shrink-0 lg:flex-shrink ${activeTab === "booking"  ? "bg-[#D96073] rounded-2xl" : ""}`}
                value="booking"
                onClick={() => setActiveTab("booking")}
              >
                <svg
                  width="24"
                  height="24"
                  viewBox="0 0 32 32"
                  fill="none"
                  xmlns="http://www.w3.org/2000/svg"
                  className="flex-shrink-0"
                >
                  <g clipPath="url(#clip0_545_63)">
                    <path
                      d="M21.3333 4C21.687 4 22.0261 4.14048 22.2761 4.39052C22.5262 4.64057 22.6667 4.97971 22.6667 5.33333V6.66667H25.3333C26.0061 6.66645 26.6541 6.92054 27.1474 7.378C27.6407 7.83545 27.9429 8.46246 27.9933 9.13333L28 9.33333V25.3333C28.0002 26.0061 27.7461 26.6541 27.2887 27.1474C26.8312 27.6407 26.2042 27.9429 25.5333 27.9933L25.3333 28H6.66667C5.9939 28.0002 5.34591 27.7461 4.8526 27.2887C4.35929 26.8312 4.05712 26.2042 4.00667 25.5333L4 25.3333V9.33333C3.99979 8.66056 4.25388 8.01258 4.71133 7.51927C5.16878 7.02596 5.79579 6.72379 6.46667 6.67333L6.66667 6.66667H9.33333V5.33333C9.33333 4.97971 9.47381 4.64057 9.72386 4.39052C9.97391 4.14048 10.313 4 10.6667 4C11.0203 4 11.3594 4.14048 11.6095 4.39052C11.8595 4.64057 12 4.97971 12 5.33333V6.66667H20V5.33333C20 4.97971 20.1405 4.64057 20.3905 4.39052C20.6406 4.14048 20.9797 4 21.3333 4ZM19.7653 12.5053L14.1093 18.1613L12.2227 16.276C11.9712 16.0331 11.6344 15.8987 11.2848 15.9018C10.9352 15.9048 10.6008 16.045 10.3536 16.2922C10.1064 16.5395 9.96614 16.8739 9.9631 17.2235C9.96006 17.5731 10.0945 17.9099 10.3373 18.1613L13.156 20.9813C13.2811 21.1065 13.4296 21.2058 13.593 21.2736C13.7565 21.3413 13.9317 21.3762 14.1087 21.3762C14.2856 21.3762 14.4608 21.3413 14.6243 21.2736C14.7878 21.2058 14.9363 21.1065 15.0613 20.9813L21.6507 14.3907C21.778 14.2677 21.8796 14.1205 21.9495 13.9579C22.0193 13.7952 22.0561 13.6202 22.0577 13.4432C22.0592 13.2662 22.0255 13.0906 21.9584 12.9267C21.8914 12.7629 21.7924 12.614 21.6672 12.4888C21.542 12.3636 21.3931 12.2646 21.2293 12.1976C21.0654 12.1305 20.8898 12.0968 20.7128 12.0983C20.5358 12.0999 20.3608 12.1367 20.1981 12.2065C20.0355 12.2764 19.8883 12.378 19.7653 12.5053Z"
                      fill="#FFF6EF"
                    />
                  </g>
                  <defs>
                    <clipPath id="clip0_545_63">
                      <rect width="32" height="32" fill="white" />
                    </clipPath>
                  </defs>
                </svg>
                <span className="text-sm sm:text-base">Bookings</span>
              </button>
              <button
                 className={`cursor-pointer flex p-3 sm:p-4 gap-2 h-11 items-center whitespace-nowrap flex-shrink-0 lg:flex-shrink ${activeTab === "chat" ? "bg-[#D96073] rounded-2xl" : ""}`}
                value="chat"
                onClick={() => setActiveTab("chat")}
              >
                <svg
                  width="24"
                  height="24"
                  viewBox="0 0 34 32"
                  fill="none"
                  xmlns="http://www.w3.org/2000/svg"
                  className="flex-shrink-0"
                >
                  <path
                    d="M13.3333 3C20.6973 3 26.6667 8.96934 26.6667 16.3333C26.6667 23.6973 20.6973 29.6667 13.3333 29.6667H2.66667C1.95942 29.6667 1.28115 29.3857 0.781049 28.8856C0.280952 28.3855 0 27.7072 0 27V16.3333C0 8.96934 5.96934 3 13.3333 3ZM13.3333 5.66667C10.5044 5.66667 7.79125 6.79047 5.79086 8.79086C3.79047 10.7913 2.66667 13.5044 2.66667 16.3333V27H13.3333C16.1623 27 18.8754 25.8762 20.8758 23.8758C22.8762 21.8754 24 19.1623 24 16.3333C24 13.5044 22.8762 10.7913 20.8758 8.79086C18.8754 6.79047 16.1623 5.66667 13.3333 5.66667ZM13.3333 19C13.6732 19.0004 14 19.1305 14.2472 19.3638C14.4943 19.5971 14.643 19.9159 14.6629 20.2552C14.6828 20.5945 14.5724 20.9285 14.3543 21.1891C14.1362 21.4497 13.8268 21.6172 13.4893 21.6573L13.3333 21.6667H9.33333C8.9935 21.6663 8.66663 21.5362 8.41951 21.3029C8.1724 21.0696 8.02369 20.7507 8.00377 20.4115C7.98386 20.0722 8.09423 19.7382 8.31235 19.4776C8.53047 19.217 8.83987 19.0495 9.17734 19.0093L9.33333 19H13.3333ZM17.3333 13.6667C17.687 13.6667 18.0261 13.8071 18.2761 14.0572C18.5262 14.3072 18.6667 14.6464 18.6667 15C18.6667 15.3536 18.5262 15.6928 18.2761 15.9428C18.0261 16.1929 17.687 16.3333 17.3333 16.3333H9.33333C8.97971 16.3333 8.64057 16.1929 8.39053 15.9428C8.14048 15.6928 8 15.3536 8 15C8 14.6464 8.14048 14.3072 8.39053 14.0572C8.64057 13.8071 8.97971 13.6667 9.33333 13.6667H17.3333Z"
                    fill="#FFF6EF"
                  />
                </svg>
                <span className="text-sm sm:text-base">Chats</span>
              </button>
              <button
                 className={`cursor-pointer flex p-3 sm:p-4 gap-2 h-11 items-center whitespace-nowrap flex-shrink-0 lg:flex-shrink ${activeTab === "subscription" ? "bg-[#D96073] rounded-2xl" : ""}`}
                value="subscription"
                onClick={() => setActiveTab("subscription")}
              >
                <svg
                  width="24"
                  height="24"
                  viewBox="0 0 32 32"
                  fill="none"
                  xmlns="http://www.w3.org/2000/svg"
                  className="flex-shrink-0"
                >
                  <g clipPath="url(#clip0_545_68)">
                    <path
                      d="M23.2269 4C23.6598 3.99996 24.0862 4.10531 24.4692 4.30695C24.8523 4.50859 25.1805 4.80045 25.4255 5.15733L25.5415 5.344L29.9869 13.12C30.2583 13.5946 30.3772 14.1412 30.3276 14.6857C30.278 15.2302 30.0622 15.7462 29.7095 16.164L29.5575 16.328L17.1802 28.7053C16.8899 28.9956 16.5026 29.1685 16.0927 29.1909C15.6828 29.2132 15.2791 29.0836 14.9589 28.8267L14.8229 28.7067L2.44553 16.328C2.0589 15.9415 1.80038 15.4456 1.70498 14.9073C1.60959 14.369 1.68192 13.8145 1.9122 13.3187L2.0162 13.1187L6.4602 5.34267C6.67498 4.96677 6.97806 4.64881 7.34324 4.41628C7.70842 4.18374 8.12473 4.04361 8.5562 4.008L8.77353 4H23.2269ZM23.2269 6.66667H8.77353L4.32953 14.444L16.0002 26.1147L27.6709 14.444L23.2269 6.66667ZM9.7242 12.3907C9.95379 12.1611 10.2593 12.0232 10.5833 12.0028C10.9073 11.9824 11.2277 12.081 11.4842 12.28L11.6095 12.3907L16.0002 16.7813L20.3909 12.3907C20.6308 12.1515 20.9528 12.0127 21.2914 12.0024C21.63 11.992 21.9598 12.111 22.2139 12.335C22.468 12.559 22.6273 12.8714 22.6594 13.2086C22.6915 13.5459 22.5941 13.8827 22.3869 14.1507L22.2762 14.276L17.1789 19.3733C16.8885 19.6636 16.5013 19.8365 16.0914 19.8589C15.6815 19.8812 15.2777 19.7516 14.9575 19.4947L14.8215 19.3747L9.7242 14.276C9.47424 14.026 9.33381 13.6869 9.33381 13.3333C9.33381 12.9798 9.47424 12.6407 9.7242 12.3907Z"
                      fill="#FFF6EF"
                    />
                  </g>
                  <defs>
                    <clipPath id="clip0_545_68">
                      <rect width="32" height="32" fill="white" />
                    </clipPath>
                  </defs>
                </svg>
                <span className="text-sm sm:text-base">Subscription</span>
              </button>
            </div>
          </div>
        </div>

        {/* right side main content */}
        <div className="w-full lg:w-2/3 xl:w-3/4 overflow-hidden bg-[#EED4CF] min-h-[500px] lg:h-[700px] my-4 mx-4 lg:my-9.5 lg:mx-0 lg:mr-4 rounded-4xl">
          {activeTab === "booking" && <BookingPage />}
          {activeTab === "chat" && <ChatPage />}
          {activeTab === "subscription" && <SubscriptionPage />}
        </div>
      </section>
    </div>
  );
}
